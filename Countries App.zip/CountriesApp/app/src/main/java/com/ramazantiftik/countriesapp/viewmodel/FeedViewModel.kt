package com.ramazantiftik.countriesapp.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ramazantiftik.countriesapp.model.Country

class FeedViewModel : ViewModel() {
    val countries= MutableLiveData<List<Country>>()
    val countryErrorText=MutableLiveData<Boolean>()
    val countryLoading=MutableLiveData<Boolean>()

    fun refreshData(){



    }

}